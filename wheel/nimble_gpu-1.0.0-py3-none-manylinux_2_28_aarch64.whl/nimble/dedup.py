"""The caller's side of NIMBLE_MATRIX_FLAG_DEDUP.

The library keeps its byte contract; this module derives, from a token
routing, everything the descriptor asks for -- the receive matrix in rows,
the node-row and chunk-row tables of the STAGED rows, the stage index and
mask -- and the send and receive layouts the library defines.
Every rank passes the same tables, so the local counts of all ranks are
exchanged first (`pack_counts` -> gather -> `Tables.from_gathered`); the
exchange itself stays with the caller (torch.distributed; nimble.moe's
Dispatcher plans on the device and gathers one count vector).

The row rule: for a source s and a node m other than s's own, a
token's row is STAGED when it is bound for two or more ranks of m, or for the
relay p(s, m) = m * G + local(s) alone; every other row is DIRECT -- the own
node's rows always, and a remote row with one destination that is not the
relay. A direct row takes the normal path (once per row); a staged row
crosses once, to the relay, which fans it out.

Rank r of nranks = nodes * gpus_per_node lives on node r // G with local index
r % G (node-major ranks, the library refuses anything else). The chunk rule
(`rows_per_chunk`) is the library's: ask it when a library is loaded, the
arithmetic here is the same function.
"""

from __future__ import annotations

import ctypes
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from . import _capi

CHUNK_BYTES = 8 << 20
FANOUT = _capi.DEDUP_FANOUT
REDUCE = _capi.DEDUP_REDUCE


def align16(value: int) -> int:
    return (int(value) + 15) & ~15


def rows_per_chunk(row_bytes: int, mode: int, lib: Any = None) -> int:
    """Rows of one 8 MiB chunk: fan-out, the largest count whose mask header
    (one byte per row, padded to 16) plus rows fit; reduce, the chunk divided
    by the row. `lib` (a loaded libnimble) answers through
    nimble_dedup_rows_per_chunk; without it the same arithmetic runs here."""
    row_bytes = int(row_bytes)
    if row_bytes <= 0 or row_bytes % 16:
        raise ValueError(f"row bytes {row_bytes} must be a positive multiple of 16")
    if mode not in (FANOUT, REDUCE):
        raise ValueError(f"unknown dedup mode {mode}")
    if lib is not None:
        out = ctypes.c_uint32(0)
        result = lib.nimble_dedup_rows_per_chunk(row_bytes, mode, ctypes.byref(out))
        _capi.check(lib, result, "nimble_dedup_rows_per_chunk")
        return int(out.value)
    if mode == REDUCE:
        n = CHUNK_BYTES // row_bytes
    else:
        n = CHUNK_BYTES // (row_bytes + 1)
        while n and align16(n) + n * row_bytes > CHUNK_BYTES:
            n -= 1
    if n == 0:
        raise ValueError(f"row bytes {row_bytes} is larger than a chunk")
    return n


def stream_bytes(rows: int, per_chunk: int, row_bytes: int, mode: int) -> int:
    """Wire bytes of a stream of `rows` rows: every full chunk occupies 8 MiB,
    the last its exact bytes (fan-out chunks carry the mask header)."""
    rows = int(rows)
    if rows == 0:
        return 0
    chunks = -(-rows // per_chunk)
    last = rows - (chunks - 1) * per_chunk
    last_bytes = align16(last) + last * row_bytes if mode == FANOUT else last * row_bytes
    return (chunks - 1) * CHUNK_BYTES + last_bytes


def chunk_capacity(max_rows: int, per_chunk: int) -> int:
    """C_max for tables whose node rows never exceed `max_rows` (every rank
    must use the same value: derive it from a shared bound, not local counts)."""
    return max(1, -(-int(max_rows) // int(per_chunk)))


def staged_masks(hit: np.ndarray, rank: int, gpus_per_node: int) -> tuple[np.ndarray, np.ndarray]:
    """The row rule over a [tokens][N][G] membership of rank `rank`'s tokens:
    returns (staged [tokens][N] bool, mask [tokens][N] uint8 -- the local-rank
    bits of every (token, node) with any member; only the staged ones are
    sent as masks)."""
    G = int(gpus_per_node)
    T, N, _ = hit.shape
    bits = (np.uint8(1) << np.arange(G, dtype=np.uint8))
    mask = (hit.astype(np.uint8) * bits).sum(axis=2).astype(np.uint8)          # [T][N]
    count = hit.sum(axis=2)                                                     # [T][N]
    own, ls = int(rank) // G, int(rank) % G
    staged = (count >= 2) | (mask == np.uint8(1 << ls))
    staged[:, own] = False
    staged &= count > 0
    return staged, mask


@dataclass
class LocalRouting:
    """One rank's routing as the calls see it (tokens in row order), split by
    the row rule. The chunk table is cut by ONE call's chunk rule; a combine
    whose row differs from the dispatch's needs its own cut (`chunk_rows_reduce`,
    gathered in the same exchange), because the library reads the table in
    the calling collective's chunking."""
    rank: int
    world_size: int
    gpus_per_node: int
    matrix_row: np.ndarray     # [R] uint64, rows bound for each rank (direct + staged: the receive matrix's row)
    direct_rows: np.ndarray    # [R] uint64, the direct rows per destination (the send buffer's blocks)
    node_rows: np.ndarray      # [N] uint64, STAGED rows bound for each node
    chunk_rows: np.ndarray     # [N][C][G] uint32, the dispatch's cut
    stage_index: np.ndarray    # int32, node-major: the TOKEN of each stage-1 row
    stage_mask: np.ndarray     # uint8, the same shape: bit d = bound for local rank d
    node_offsets: np.ndarray   # [N + 1] int64, node m's rows are stage_index[off[m]:off[m+1]]
    direct: np.ndarray         # [tokens][R] bool, the direct membership
    staged: np.ndarray         # [tokens][N] bool, the token is staged for node m
    chunk_rows_reduce: np.ndarray | None = None   # [N][C_r][G] uint32, the combine's cut

    @property
    def tokens(self) -> int:
        return int(self.direct.shape[0])

    def pack_counts(self) -> np.ndarray:
        """The uint64 vector every rank exchanges: matrix row, node rows, chunk
        rows, then the combine's chunk rows when they were cut."""
        parts = [self.matrix_row.astype(np.uint64), self.node_rows.astype(np.uint64),
                 self.chunk_rows.reshape(-1).astype(np.uint64)]
        if self.chunk_rows_reduce is not None:
            parts.append(self.chunk_rows_reduce.reshape(-1).astype(np.uint64))
        return np.concatenate(parts)

    # -- the send layout: the direct blocks in rank order, then the pool --
    def direct_total(self) -> int:
        return int(self.direct_rows.sum())

    def send_rows(self) -> int:
        """Rows of the fan-out send buffer: the direct blocks, then one row per token."""
        return self.direct_total() + self.tokens

    def direct_tokens(self, d: int) -> np.ndarray:
        """The tokens of the direct rows bound for rank d, in token order."""
        return np.flatnonzero(self.direct[:, int(d)])

    def send_index(self) -> np.ndarray:
        """The stage index as the descriptor wants it: SEND-buffer rows (the
        pool follows the direct blocks)."""
        return (self.stage_index.astype(np.int64) + self.direct_total()).astype(np.int32)


def _chunk_table(staged: np.ndarray, hit: np.ndarray, per_chunk: int, capacity: int, G: int) -> np.ndarray:
    N = staged.shape[1]
    chunk_rows = np.zeros((N, capacity, G), dtype=np.uint32)
    for m in range(N):
        toks = np.flatnonzero(staged[:, m])
        masks = hit[toks, m, :]
        n = int(toks.size)
        chunks = -(-n // per_chunk)
        if chunks > capacity:
            raise ValueError(f"node {m}: {n} rows need {chunks} chunks, capacity {capacity}")
        for c in range(chunks):
            chunk_rows[m, c, :] = masks[c * per_chunk:(c + 1) * per_chunk].sum(axis=0)
    return chunk_rows


def local_routing(dest: np.ndarray, gpus_per_node: int, per_chunk: int, capacity: int, *, rank: int,
                  per_chunk_reduce: int | None = None, capacity_reduce: int | None = None) -> LocalRouting:
    """`dest` is the [tokens][nranks] boolean membership (token t is routed to
    rank r) of rank `rank`; ranks node-major. The staged rows of a node are
    its staged tokens in token order; chunk c of that stream holds rows
    [c * per_chunk, (c + 1) * per_chunk). `per_chunk_reduce` /
    `capacity_reduce` also cut the combine's table."""
    dest = np.asarray(dest, dtype=bool)
    if dest.ndim != 2:
        raise ValueError("dest must be [tokens][nranks]")
    tokens, world = dest.shape
    G = int(gpus_per_node)
    if world % G:
        raise ValueError(f"nranks {world} is not a multiple of gpus_per_node {G}")
    if not 0 <= int(rank) < world:
        raise ValueError(f"rank {rank} outside [0, {world})")
    N = world // G
    hit = dest.reshape(tokens, N, G)
    staged, mask = staged_masks(hit, rank, G)
    direct = dest & ~np.repeat(staged, G, axis=1)
    matrix_row = dest.sum(axis=0).astype(np.uint64)
    direct_rows = direct.sum(axis=0).astype(np.uint64)
    node_rows = staged.sum(axis=0).astype(np.uint64)
    chunk_rows = _chunk_table(staged, hit, per_chunk, capacity, G)
    reduce_table = None
    if per_chunk_reduce is not None:
        if capacity_reduce is None:
            raise ValueError("capacity_reduce is needed with per_chunk_reduce")
        reduce_table = _chunk_table(staged, hit, int(per_chunk_reduce), int(capacity_reduce), G)
    index_parts, mask_parts, offsets = [], [], [0]
    for m in range(N):
        toks = np.flatnonzero(staged[:, m])
        index_parts.append(toks.astype(np.int32))
        mask_parts.append(mask[toks, m].astype(np.uint8))
        offsets.append(offsets[-1] + int(toks.size))
    return LocalRouting(int(rank), world, G, matrix_row, direct_rows, node_rows, chunk_rows,
                        np.concatenate(index_parts) if index_parts else np.zeros(0, np.int32),
                        np.concatenate(mask_parts) if mask_parts else np.zeros(0, np.uint8),
                        np.asarray(offsets, dtype=np.int64), direct, staged, reduce_table)


@dataclass
class FanoutLayout:
    """The fan-out receive buffer at one rank, bytes."""
    region0: int
    region1: int
    direct_base: np.ndarray    # [R] where source s's direct rows for me start
    staged_base: np.ndarray    # [R] where source s's staged rows for me start
    landing_base: np.ndarray   # [R] where source s's stage-1 stream lands (I relay it)


@dataclass
class ReduceLayout:
    """The reduce receive buffer at one rank, bytes: region 0 per remote rank
    in rank order (the node's return chunks from its relay, direct rows from
    every other rank), region 1 per local rank in rank order (the producer
    landing: the contributions it holds for the streams I relay, then my
    direct rows from it; the diagonal slot)."""
    region0: int
    region1: int
    return_base: np.ndarray         # [N] node m's return chunks (8 MiB-strided); 0 for my own node
    direct_return_base: np.ndarray  # [R] where rank d's direct rows for me start (every d, my own too)
    producer_base: np.ndarray       # [R] the producer landing of local d != me (0 elsewhere)


@dataclass
class Tables:
    """Every rank's counts (identical on all ranks after the exchange). The
    chunk table is in the chunking of the call it is passed to; `for_reduce()`
    swaps in the combine's cut when one was gathered."""
    world_size: int
    gpus_per_node: int
    capacity: int
    matrix_rows: np.ndarray    # [R][R] uint64, rows dst holds from src (direct + staged)
    node_rows: np.ndarray      # [R][N] uint64, the staged rows
    chunk_rows: np.ndarray     # [R][N][C][G] uint32
    capacity_reduce: int | None = None
    chunk_rows_reduce: np.ndarray | None = None   # [R][N][C_r][G] uint32

    @property
    def nodes(self) -> int:
        return self.world_size // self.gpus_per_node

    @staticmethod
    def from_gathered(gathered: np.ndarray, world_size: int, gpus_per_node: int, capacity: int,
                      capacity_reduce: int | None = None) -> "Tables":
        """`gathered` is [R][len] of every rank's pack_counts()."""
        R, G, C = int(world_size), int(gpus_per_node), int(capacity)
        N = R // G
        g = np.asarray(gathered, dtype=np.uint64).reshape(R, -1)
        expected = R + N + N * C * G
        Cr = int(capacity_reduce) if capacity_reduce is not None else None
        if Cr is not None:
            expected += N * Cr * G
        if g.shape[1] != expected:
            raise ValueError(f"gathered counts have {g.shape[1]} entries per rank, expected {expected}")
        base = R + N + N * C * G
        reduce_table = g[:, base:].reshape(R, N, Cr, G).astype(np.uint32) if Cr is not None else None
        return Tables(R, G, C, g[:, :R].copy(), g[:, R:R + N].copy(),
                      g[:, R + N:base].reshape(R, N, C, G).astype(np.uint32), Cr, reduce_table)

    def for_reduce(self) -> "Tables":
        """The same counts with the combine's chunk cut as THE chunk table."""
        if self.chunk_rows_reduce is None or self.capacity_reduce is None:
            raise ValueError("no combine chunk table was gathered (local_routing(..., per_chunk_reduce=))")
        return Tables(self.world_size, self.gpus_per_node, self.capacity_reduce, self.matrix_rows,
                      self.node_rows, self.chunk_rows_reduce)

    def matrix_bytes(self, row_bytes: int) -> np.ndarray:
        return self.matrix_rows * np.uint64(row_bytes)

    # -- the row split, [R][R] int64 -------------------------------------------
    def staged_rows(self) -> np.ndarray:
        """staged(s, d) = the chunk table's column of d in the stream (s, node(d))."""
        R, G, N = self.world_size, self.gpus_per_node, self.nodes
        columns = self.chunk_rows.astype(np.int64).sum(axis=2)          # [R][N][G]
        return columns.reshape(R, N * G)

    def direct_rows(self) -> np.ndarray:
        direct = self.matrix_rows.astype(np.int64) - self.staged_rows()
        if (direct < 0).any():
            raise ValueError("the chunk tables exceed the matrix")
        return direct

    def check_row_rule(self) -> None:
        """The library's two refusals: staged rows for the own node, direct rows on a relay pair."""
        R, G = self.world_size, self.gpus_per_node
        direct = self.direct_rows()
        for s in range(R):
            if int(self.node_rows[s, s // G]) != 0:
                raise ValueError(f"rank {s} stages rows for its own node")
            for m in range(self.nodes):
                if m != s // G and direct[s, m * G + s % G] != 0:
                    raise ValueError(f"rank {s} has direct rows on its relay pair with node {m}")

    # -- the layouts (the mirror of the library's dedup_prepare) ----------------
    def region0_bases(self, rank: int, row_bytes: int) -> tuple[np.ndarray, np.ndarray, int]:
        """Region 0 of the fan-out receive buffer at `rank` in rows of
        `row_bytes` (also the reduce's send buffer in the combine row): by
        rail group l = 0..G-1, [direct of the remote sources on rail l, rank
        order] [staged of the remote sources on rail l, rank order] [direct of
        the own-node source of rail l] (the staged blocks lead, so the
        producer range (rank -> own-node source of rail l) = [staged blocks |
        direct block] sends the rows that gate the relay's return streams
        first). Returns (direct_base [R], staged_base [R], extent);
        staged_base of the own-node source marks the rail group's staged
        begin."""
        R, G = self.world_size, self.gpus_per_node
        d = int(rank)
        direct, staged = self.direct_rows(), self.staged_rows()
        direct_base = np.zeros(R, dtype=np.int64)
        staged_base = np.zeros(R, dtype=np.int64)
        off = 0
        for l in range(G):
            own = (d // G) * G + l
            for s in range(l, R, G):
                if s == own:
                    continue
                direct_base[s] = off
                off += int(direct[s, d]) * int(row_bytes)
            staged_base[own] = off
            for s in range(l, R, G):
                if s == own:
                    continue
                staged_base[s] = off
                off += int(staged[s, d]) * int(row_bytes)
            direct_base[own] = off
            off += int(direct[own, d]) * int(row_bytes)
        return direct_base, staged_base, off

    def fanout_layout(self, rank: int, row_bytes: int, per_chunk: int) -> FanoutLayout:
        R, G = self.world_size, self.gpus_per_node
        d = int(rank)
        direct_base, staged_base, region0 = self.region0_bases(d, row_bytes)
        landing_base = np.zeros(R, dtype=np.int64)
        off = region0
        for s in range(R):
            landing_base[s] = off
            if s // G != d // G and s % G == d % G:
                off += stream_bytes(int(self.node_rows[s, d // G]), per_chunk, row_bytes, FANOUT)
        return FanoutLayout(region0, off - region0, direct_base, staged_base, landing_base)

    def send_direct_offsets(self, rank: int, row_bytes: int) -> np.ndarray:
        """[R] byte offsets of the direct blocks in `rank`'s fan-out send buffer (rank order)."""
        direct = self.direct_rows()[int(rank)] * np.int64(row_bytes)
        return np.concatenate([[0], np.cumsum(direct)[:-1]]).astype(np.int64)

    def reduce_layout(self, rank: int, row_bytes: int, per_chunk: int) -> ReduceLayout:
        R, G, N = self.world_size, self.gpus_per_node, self.nodes
        s = int(rank)
        ms, ls = s // G, s % G
        direct, staged = self.direct_rows(), self.staged_rows()
        return_base = np.zeros(N, dtype=np.int64)
        direct_return_base = np.zeros(R, dtype=np.int64)
        producer_base = np.zeros(R, dtype=np.int64)
        off = 0
        for d in range(R):
            if d // G == ms:
                continue
            if d % G == ls:
                return_base[d // G] = off
                off += stream_bytes(int(self.node_rows[s, d // G]), per_chunk, row_bytes, REDUCE)
            else:
                direct_return_base[d] = off
                off += int(direct[s, d]) * int(row_bytes)
        region0 = off
        for dl in range(G):
            d = ms * G + dl
            staged_bytes = 0
            if d != s:
                for s2 in range(ls, R, G):
                    if s2 // G == ms:
                        continue
                    staged_bytes += int(staged[s2, d]) * int(row_bytes)
                producer_base[d] = off
            # the producer landing is [the contributions | my direct rows from d]
            direct_return_base[d] = off + staged_bytes
            off += staged_bytes + int(direct[s, d]) * int(row_bytes)
        return ReduceLayout(region0, off - region0, return_base, direct_return_base, producer_base)

    def reduce_send_bytes(self, rank: int, row_bytes: int) -> int:
        return int(self.matrix_rows[:, rank].sum()) * int(row_bytes)


@dataclass
class DedupCall:
    """What alltoallv_bytes(..., dedup=) puts on the descriptor."""
    mode: int
    row_bytes: int
    tables: Tables
    send_rows: int = 0                      # fan-out: rows in the send buffer (the direct blocks and the pool)
    stage_index_ptr: int = 0                # fan-out: device int32[] of SEND rows (LocalRouting.send_index)
    stage_mask_ptr: int = 0                 # fan-out: device uint8[]
    dispatch_row_bytes: int = 0             # reduce: the fan-out call's row
    dispatch_landing_ptr: int = 0           # reduce: the fan-out call's receive buffer
    _keep: list = field(default_factory=list, repr=False)

    def fill(self, descriptor: Any, comm: Any) -> list:
        if self.tables.world_size != comm.world_size or self.tables.gpus_per_node != comm.local_world_size:
            raise ValueError("dedup tables do not match the communicator's shape")
        node_rows = np.ascontiguousarray(self.tables.node_rows, dtype=np.uint64)
        chunk_rows = np.ascontiguousarray(self.tables.chunk_rows, dtype=np.uint32)
        descriptor.flags |= _capi.MATRIX_FLAG_DEDUP
        descriptor.dedup_mode = int(self.mode)
        descriptor.dedup_chunk_capacity = int(self.tables.capacity)
        descriptor.dedup_row_bytes = int(self.row_bytes)
        descriptor.dedup_dispatch_row_bytes = int(self.dispatch_row_bytes)
        descriptor.dedup_send_rows = int(self.send_rows)
        descriptor.dedup_node_rows = node_rows.ctypes.data
        descriptor.dedup_chunk_rows = chunk_rows.ctypes.data
        descriptor.dedup_stage_index = int(self.stage_index_ptr) or None
        descriptor.dedup_stage_mask = int(self.stage_mask_ptr) or None
        descriptor.dedup_dispatch_landing = int(self.dispatch_landing_ptr) or None
        return [node_rows, chunk_rows]
