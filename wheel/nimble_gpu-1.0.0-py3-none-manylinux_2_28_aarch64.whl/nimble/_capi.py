"""ctypes binding of the public NIMBLE C API (include/nimble/nimble.h).

Pure Python, no compiled extension, no private header: the package reaches
the library only through the exported symbols and the tagged structures of
nimble.h, bound field for field with struct_size / abi_version set as the
header prescribes.
"""

from __future__ import annotations

import ctypes
import ctypes.util
import os
import pathlib
import threading

ABI_VERSION = 2
MATRIX_FLAG_HOST_BYTES = 1
MATRIX_FLAG_DEDUP = 2          # the MoE two-hop inside one call
DEDUP_FANOUT = 1
DEDUP_REDUCE = 2

SUCCESS = 0
ERROR_NAMES = {
    0: "NIMBLE_SUCCESS",
    1: "NIMBLE_ERROR_INVALID_ARGUMENT",
    2: "NIMBLE_ERROR_NOT_INITIALIZED",
    3: "NIMBLE_ERROR_NOT_SUPPORTED",
    4: "NIMBLE_ERROR_INTERNAL",
    5: "NIMBLE_ERROR_RESOURCE_EXHAUSTED",
    6: "NIMBLE_ERROR_ABORTED",
}


class InitConfig(ctypes.Structure):
    """nimbleInitConfig_t."""

    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("abi_version", ctypes.c_uint32),
        ("rank", ctypes.c_int32),
        ("nranks", ctypes.c_int32),
        ("local_rank", ctypes.c_int32),
        ("local_nranks", ctypes.c_int32),
        ("cuda_device", ctypes.c_int32),
        ("bootstrap", ctypes.c_char_p),
        ("bootstrap_timeout_ms", ctypes.c_uint32),
        ("reserved0", ctypes.c_uint32),
    ]


class WorkloadMatrix(ctypes.Structure):
    """nimbleWorkloadMatrix_t."""

    _fields_ = [
        ("struct_size", ctypes.c_uint32),
        ("abi_version", ctypes.c_uint32),
        ("nranks", ctypes.c_int32),
        ("flags", ctypes.c_uint32),
        ("matrix_stride", ctypes.c_uint64),
        ("device_bytes", ctypes.c_void_p),
        # appended for MATRIX_FLAG_DEDUP (struct_size-gated)
        ("dedup_mode", ctypes.c_uint32),
        ("dedup_chunk_capacity", ctypes.c_uint32),
        ("dedup_row_bytes", ctypes.c_uint64),
        ("dedup_dispatch_row_bytes", ctypes.c_uint64),
        ("dedup_send_rows", ctypes.c_uint64),
        ("dedup_node_rows", ctypes.c_void_p),
        ("dedup_chunk_rows", ctypes.c_void_p),
        ("dedup_stage_index", ctypes.c_void_p),
        ("dedup_stage_mask", ctypes.c_void_p),
        ("dedup_dispatch_landing", ctypes.c_void_p),
    ]


INIT_CONFIG_SIZE = 48
WORKLOAD_MATRIX_SIZE = 104
assert ctypes.sizeof(InitConfig) == INIT_CONFIG_SIZE
assert ctypes.sizeof(WorkloadMatrix) == WORKLOAD_MATRIX_SIZE


def init_config() -> InitConfig:
    """NIMBLE_INIT_CONFIG_INITIALIZER."""
    return InitConfig(INIT_CONFIG_SIZE, ABI_VERSION, -1, 0, -1, 0, -1, None, 0, 0)


def workload_matrix() -> WorkloadMatrix:
    """NIMBLE_WORKLOAD_MATRIX_INITIALIZER."""
    return WorkloadMatrix(WORKLOAD_MATRIX_SIZE, ABI_VERSION, 0, 0, 0, None,
                          0, 0, 0, 0, 0, None, None, None, None, None)


class NimbleError(RuntimeError):
    """A NIMBLE call returned a result other than NIMBLE_SUCCESS."""

    def __init__(self, what: str, code: int, detail: str = "") -> None:
        self.code = int(code)
        self.name = ERROR_NAMES.get(self.code, f"NIMBLE_ERROR_{self.code}")
        message = f"{what}: {self.name}"
        if detail and detail != "success":
            message += f": {detail}"
        super().__init__(message)


def repository_root() -> pathlib.Path:
    return pathlib.Path(__file__).resolve().parents[2]


def candidate_library_paths() -> list[pathlib.Path]:
    """Where libnimble.so is looked for, in order: NIMBLE_LIBRARY, a library
    bundled with this package (nimble/lib: the wheel's), the tree's build
    directories, then the loader path."""
    paths: list[pathlib.Path] = []
    env = os.environ.get("NIMBLE_LIBRARY")
    if env:
        paths.append(pathlib.Path(env))
    paths.append(pathlib.Path(__file__).resolve().parent / "lib" / "libnimble.so")
    root = repository_root()
    for build in ("build-v2", "build-login", "build", "build-v2-trace"):
        paths.append(root / build / "libnimble.so")
    found = ctypes.util.find_library("nimble")
    if found:
        paths.append(pathlib.Path(found))
    return paths


_lock = threading.Lock()
_library: ctypes.CDLL | None = None
_library_path: pathlib.Path | None = None


def _bind(lib: ctypes.CDLL) -> None:
    lib.nimble_get_version.argtypes = [ctypes.POINTER(ctypes.c_uint32)]
    lib.nimble_get_version.restype = ctypes.c_int
    lib.nimble_get_version_string.argtypes = []
    lib.nimble_get_version_string.restype = ctypes.c_char_p
    lib.nimble_get_error_string.argtypes = [ctypes.c_int]
    lib.nimble_get_error_string.restype = ctypes.c_char_p
    lib.nimble_get_last_error.argtypes = [ctypes.c_void_p]
    lib.nimble_get_last_error.restype = ctypes.c_char_p
    lib.nimble_comm_init.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(InitConfig)]
    lib.nimble_comm_init.restype = ctypes.c_int
    lib.nimble_comm_destroy.argtypes = [ctypes.c_void_p]
    lib.nimble_comm_destroy.restype = ctypes.c_int
    lib.nimble_comm_get_async_error.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_int)]
    lib.nimble_comm_get_async_error.restype = ctypes.c_int
    lib.nimble_comm_abort.argtypes = [ctypes.c_void_p]
    lib.nimble_comm_abort.restype = ctypes.c_int
    lib.nimble_alltoallv.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                                     ctypes.POINTER(WorkloadMatrix), ctypes.c_void_p]
    lib.nimble_alltoallv.restype = ctypes.c_int
    lib.nimble_dedup_rows_per_chunk.argtypes = [ctypes.c_uint64, ctypes.c_uint32,
                                                ctypes.POINTER(ctypes.c_uint32)]
    lib.nimble_dedup_rows_per_chunk.restype = ctypes.c_int


def load_library(path: str | os.PathLike | None = None) -> ctypes.CDLL:
    """Load libnimble.so once per process (ctypes releases the GIL around
    every call, so the host-matrix admission wait does not block other
    Python threads)."""
    global _library, _library_path
    with _lock:
        if _library is not None:
            if path is not None and pathlib.Path(path).resolve() != _library_path:
                raise RuntimeError(f"NIMBLE library already loaded from {_library_path}")
            return _library
        candidates = [pathlib.Path(path)] if path is not None else candidate_library_paths()
        errors = []
        for candidate in candidates:
            if not candidate.exists():
                errors.append(f"{candidate}: not found")
                continue
            try:
                lib = ctypes.CDLL(str(candidate))
            except OSError as error:
                errors.append(f"{candidate}: {error}")
                continue
            _bind(lib)
            version = ctypes.c_uint32(0)
            if lib.nimble_get_version(ctypes.byref(version)) != SUCCESS:
                errors.append(f"{candidate}: nimble_get_version failed")
                continue
            if version.value // 10000 != 1:
                errors.append(f"{candidate}: NIMBLE major {version.value // 10000} is not 1")
                continue
            _library = lib
            _library_path = candidate.resolve()
            return lib
        raise ImportError("libnimble.so not found; set NIMBLE_LIBRARY, install the wheel or build the tree "
                          "(" + "; ".join(errors) + ")")


def library_path() -> pathlib.Path | None:
    return _library_path


def version(lib: ctypes.CDLL | None = None) -> tuple[int, int, int]:
    """(major, minor, patch) of the loaded library (NCCL encoding)."""
    lib = lib or load_library()
    value = ctypes.c_uint32(0)
    result = lib.nimble_get_version(ctypes.byref(value))
    if result != SUCCESS:
        raise NimbleError("nimble_get_version", result)
    v = value.value
    return v // 10000, (v // 100) % 100, v % 100


def version_string(lib: ctypes.CDLL | None = None) -> str:
    lib = lib or load_library()
    return lib.nimble_get_version_string().decode()


def last_error(lib: ctypes.CDLL, comm: ctypes.c_void_p | None) -> str:
    text = lib.nimble_get_last_error(comm)
    return text.decode(errors="replace") if text else ""


def check(lib: ctypes.CDLL, result: int, what: str, comm: ctypes.c_void_p | None = None) -> None:
    if result != SUCCESS:
        raise NimbleError(what, result, last_error(lib, comm))
