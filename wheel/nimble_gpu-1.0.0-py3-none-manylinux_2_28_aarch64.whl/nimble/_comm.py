"""The communicator: a thin owner of a nimbleComm_t."""

from __future__ import annotations

import ctypes
import warnings
from typing import TYPE_CHECKING

import numpy as np

from . import _capi

if TYPE_CHECKING:
    from .dedup import DedupCall


class Communicator:
    """One nimbleComm_t. Construction is collective across all ranks
    (nimble_comm_init); `destroy()` is collective too and consumes the
    handle. Use `nimble.init()` rather than this constructor under
    PyTorch: it resolves ranks, nodes and the bootstrap for you."""

    def __init__(self, *, rank: int, world_size: int, local_rank: int, local_world_size: int,
                 device: int, bootstrap: str, timeout_ms: int = 0,
                 library: str | None = None) -> None:
        self._lib = _capi.load_library(library)
        self._handle = ctypes.c_void_p(None)
        self.rank = int(rank)
        self.world_size = int(world_size)
        self.local_rank = int(local_rank)
        self.local_world_size = int(local_world_size)
        self.device = int(device)
        self.bootstrap = str(bootstrap)
        self.group = None   # the torch.distributed group nimble.init() was given
        self.bound_stream: int | None = None   # the stream of the first collective (C API contract)
        if not (0 <= self.rank < self.world_size):
            raise ValueError(f"rank {self.rank} outside [0, {self.world_size})")
        if not (0 <= self.local_rank < self.local_world_size <= self.world_size):
            raise ValueError(f"local rank {self.local_rank} / {self.local_world_size} inconsistent "
                             f"with world size {self.world_size}")
        config = _capi.init_config()
        config.rank = self.rank
        config.nranks = self.world_size
        config.local_rank = self.local_rank
        config.local_nranks = self.local_world_size
        config.cuda_device = self.device
        self._bootstrap_bytes = self.bootstrap.encode()   # must outlive the call
        config.bootstrap = self._bootstrap_bytes
        config.bootstrap_timeout_ms = int(timeout_ms)
        result = self._lib.nimble_comm_init(ctypes.byref(self._handle), ctypes.byref(config))
        _capi.check(self._lib, result, "nimble_comm_init")
        if not self._handle.value:
            raise _capi.NimbleError("nimble_comm_init", _capi.SUCCESS, "returned a null communicator")

    # -- lifetime -----------------------------------------------------------
    @property
    def handle(self) -> int:
        if not self._handle.value:
            raise RuntimeError("communicator is destroyed")
        return self._handle.value

    @property
    def alive(self) -> bool:
        return bool(self._handle.value)

    def destroy(self) -> None:
        """Collective. Consumes the handle in every outcome."""
        if not self._handle.value:
            return
        handle = self._handle
        self._handle = ctypes.c_void_p(None)
        result = self._lib.nimble_comm_destroy(handle)
        _capi.check(self._lib, result, "nimble_comm_destroy")

    def abort(self) -> None:
        result = self._lib.nimble_comm_abort(self.handle)
        _capi.check(self._lib, result, "nimble_comm_abort", self._handle)

    def async_error(self) -> int:
        """The sticky asynchronous result code (0 = none latched)."""
        code = ctypes.c_int(0)
        result = self._lib.nimble_comm_get_async_error(self.handle, ctypes.byref(code))
        _capi.check(self._lib, result, "nimble_comm_get_async_error", self._handle)
        return code.value

    def raise_async_error(self) -> None:
        code = self.async_error()
        if code != _capi.SUCCESS:
            raise _capi.NimbleError("asynchronous failure", code, _capi.last_error(self._lib, self._handle))

    def last_error(self) -> str:
        return _capi.last_error(self._lib, self._handle if self._handle.value else None)

    def __enter__(self) -> "Communicator":
        return self

    def __exit__(self, *exc) -> None:
        self.destroy()

    def __del__(self) -> None:
        handle = getattr(self, "_handle", None)
        if handle is not None and handle.value:
            warnings.warn("nimble.Communicator garbage-collected without destroy(); "
                          "destroy() is collective and must be called explicitly", ResourceWarning)

    def __repr__(self) -> str:
        return (f"Communicator(rank={self.rank}/{self.world_size}, local={self.local_rank}/"
                f"{self.local_world_size}, device={self.device}, alive={self.alive})")

    # -- the collective -------------------------------------------------------
    def alltoallv_bytes(self, send_ptr: int, recv_ptr: int, byte_matrix: np.ndarray,
                        stream: int, *, dedup: "DedupCall | None" = None) -> None:
        """nimble_alltoallv on raw device pointers with the nranks-by-nranks
        HOST byte matrix (uint64, row-major, rows = source rank). The
        library copies the matrix at call entry, so the array need not
        outlive the call. `dedup` (a nimble.dedup.DedupCall) sets
        NIMBLE_MATRIX_FLAG_DEDUP and the descriptor's dedup fields: the
        matrix is then the fused receive layout in rows of dedup.row_bytes."""
        matrix = np.ascontiguousarray(byte_matrix, dtype=np.uint64)
        if matrix.shape != (self.world_size, self.world_size):
            raise ValueError(f"byte matrix shape {matrix.shape} is not "
                             f"({self.world_size}, {self.world_size})")
        descriptor = _capi.workload_matrix()
        descriptor.nranks = self.world_size
        descriptor.flags = _capi.MATRIX_FLAG_HOST_BYTES
        descriptor.matrix_stride = 0
        descriptor.device_bytes = matrix.ctypes.data
        keep = None
        if dedup is not None:
            keep = dedup.fill(descriptor, self)   # arrays that must outlive the call
        if self.bound_stream is not None and int(stream) != self.bound_stream:
            raise ValueError(f"communicator is bound to CUDA stream {self.bound_stream:#x} by its first "
                             f"collective and cannot take stream {int(stream):#x}; use one communicator "
                             "per stream (nimble.init(set_default=False))")
        result = self._lib.nimble_alltoallv(self.handle, ctypes.c_void_p(send_ptr or None),
                                            ctypes.c_void_p(recv_ptr or None),
                                            ctypes.byref(descriptor), ctypes.c_void_p(stream))
        _capi.check(self._lib, result, "nimble_alltoallv", self._handle)
        del keep
        self.bound_stream = int(stream)
