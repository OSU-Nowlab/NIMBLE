"""Rank, node and bootstrap resolution. Pure helpers, testable without a
GPU."""

from __future__ import annotations

import os
import socket
from typing import Mapping


def free_tcp_port(host: str = "") -> int:
    """A TCP port that was free on `host` at the time of the call. Rank 0
    binds port 0, reads the number back and closes the socket; the
    library's rendezvous listener binds it right after."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((host, 0))
        return int(sock.getsockname()[1])


def node_topology(hostnames: list[str], rank: int) -> tuple[int, int]:
    """(local_rank, local_nranks) of `rank` given every rank's hostname in
    rank order: ranks on one host are numbered in rank order, which is the
    order torchrun assigns LOCAL_RANK and the order the library groups
    identities by node name."""
    if not 0 <= rank < len(hostnames):
        raise ValueError(f"rank {rank} outside [0, {len(hostnames)})")
    host = hostnames[rank]
    same = [index for index, name in enumerate(hostnames) if name == host]
    return same.index(rank), len(same)


def bootstrap_endpoint(host: str, port: int) -> str:
    if not host or not (0 < int(port) < 65536):
        raise ValueError(f"invalid bootstrap endpoint {host!r}:{port!r}")
    return f"tcp://{host}:{int(port)}"


def resolve_from_env(env: Mapping[str, str] | None = None) -> dict:
    """The torchrun environment: RANK, WORLD_SIZE, LOCAL_RANK,
    LOCAL_WORLD_SIZE and the bootstrap from NIMBLE_BOOTSTRAP, else
    tcp://MASTER_ADDR:NIMBLE_BOOTSTRAP_PORT (default MASTER_PORT + 1; the
    torch store holds MASTER_PORT itself)."""
    env = os.environ if env is None else env

    def need(name: str) -> str:
        value = env.get(name)
        if value is None or value == "":
            raise KeyError(f"{name} is not set; pass the value to nimble.init() or run under torchrun")
        return value

    rank = int(need("RANK"))
    world_size = int(need("WORLD_SIZE"))
    local_rank = int(need("LOCAL_RANK"))
    local_world_size = int(need("LOCAL_WORLD_SIZE"))
    bootstrap = env.get("NIMBLE_BOOTSTRAP")
    if not bootstrap:
        host = need("MASTER_ADDR")
        port = env.get("NIMBLE_BOOTSTRAP_PORT")
        if not port:
            port = str(int(need("MASTER_PORT")) + 1)
        bootstrap = bootstrap_endpoint(host, int(port))
    if not (0 <= rank < world_size and 0 <= local_rank < local_world_size <= world_size):
        raise ValueError(f"inconsistent rank environment: RANK={rank} WORLD_SIZE={world_size} "
                         f"LOCAL_RANK={local_rank} LOCAL_WORLD_SIZE={local_world_size}")
    return {"rank": rank, "world_size": world_size, "local_rank": local_rank,
            "local_world_size": local_world_size, "bootstrap": bootstrap}
