"""This package's version: the NIMBLE release (the git tag) and, as PEP 440's .postN, a packaging revision -- the same
library and API, repackaged."""

__version__ = "1.0.0"
