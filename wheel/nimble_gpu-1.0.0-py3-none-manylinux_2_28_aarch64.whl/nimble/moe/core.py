"""The wire row of expert-parallel dispatch, shared by the fused and dedup cores.

DeepEP-normal semantics over an AllToAllV: a token goes ONCE to each distinct destination rank among its top-k
experts and carries only the top-k entries that live there (the local expert index, -1 elsewhere, weight 0 there),
so a framework's expert path runs unchanged on what arrives. One row on the wire:

    [hidden (FP8 or BF16) | per-token scales | k int64 expert ids | k fp32 weights], padded to 16 bytes

The combine sends each received row's expert output back to its source, which sums a token's rows in fp32.
"""
from __future__ import annotations

import triton


def _round_up(value: int, multiple: int) -> int:
    return (value + multiple - 1) // multiple * multiple


class RowLayout:
    """The byte offsets of one wire row and the word counts the copy kernels use.

    rank / world: this rank in the expert-parallel group; num_local_experts: experts per rank (global expert e
    lives on rank e // num_local_experts); x_itemsize: bytes per hidden element; scale_itemsize / scale_cols: the
    per-token scale row as the quantizer stores it (0 / 0 without scales); expert_alignment: the per-expert row
    counts are rounded up to it (DeepGEMM's contiguous layout takes 128)."""

    def __init__(self, rank: int, world: int, num_local_experts: int, hidden_size: int, topk: int,
                 x_itemsize: int, scale_itemsize: int, scale_cols: int, expert_alignment: int = 1):
        self.rank, self.world = rank, world
        self.num_local_experts, self.num_experts = num_local_experts, world * num_local_experts
        self.hidden_size, self.topk = hidden_size, topk
        self.expert_alignment = expert_alignment
        self.x_bytes = hidden_size * x_itemsize
        self.s_bytes = scale_cols * scale_itemsize
        self.off_x = 0
        self.off_s = self.x_bytes
        self.off_i = _round_up(self.off_s + self.s_bytes, 8)
        self.i_bytes = topk * 8
        self.off_w = self.off_i + self.i_bytes
        self.w_bytes = topk * 4
        self.row_bytes = _round_up(self.off_w + self.w_bytes, 16)
        for name, value, unit in (("hidden bytes", self.x_bytes, 4), ("scale bytes", self.s_bytes, 4)):
            if value % unit:
                raise ValueError(f"{name} {value} is not a multiple of {unit}")
        self.x_words, self.s_words = self.x_bytes // 4, self.s_bytes // 4
        self.sp = max(2, triton.next_power_of_2(self.s_words))      # the scale words, padded for tl.arange
        self.kp = max(2, triton.next_power_of_2(topk))              # the top-k slots, padded

    def aligned(self, counts) -> list[int]:
        """Per-local-expert row counts rounded up to expert_alignment."""
        a = self.expert_alignment
        return [int((c + a - 1) // a * a) for c in counts]
