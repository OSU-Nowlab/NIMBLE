"""The fused core: MoE dispatch and combine as one AllToAllV per direction (NIMBLE or NCCL).

The send buffer holds the rows ordered by destination rank, then token (core.py's row). The work around the
transfer is four Triton launches and one count exchange, with no host wait before the exchange:

  plan     a scan per destination rank gives every token's position in that rank's block (row_pos) and the
           block's row count; a second pass per rank writes the row -> (token, rank) map the pack walks; a third,
           per token block, gives each top-k slot its send row (the first slot naming a rank owns the row, later
           ones and masked slots get -1) and the per-expert token histogram. The counts land in place in the
           vector the exchange carries: [rows per destination R | tokens per expert E].
  pack     one program per send row: the token's hidden words and scales are copied, its local expert ids and
           weights computed in the kernel. The exchange precedes the pack, so the send buffer holds exactly this
           rank's rows.
  receive  strided views of the received hidden rows and scales, contiguous ids and weights; the per-local-expert
           counts come from the gathered table (no bincount, no second host wait).
  combine  one program per token sums its rows (listed per top-k slot) in fp32 straight into the output.
"""
from __future__ import annotations

from typing import NamedTuple, Optional

import numpy as np
import torch
import triton
import triton.language as tl

from .core import RowLayout


class FusedPlan(NamedTuple):
    row_pos: torch.Tensor       # [T, R] int32: token t's position inside rank d's block, -1 when not sent there
    start: torch.Tensor         # [R] int64: rank d's first send row (the exclusive prefix of the rank rows)
    row_tok: torch.Tensor       # [cap + 1] int32: the token of send row r (rows past the used ones unwritten)
    row_dst: torch.Tensor       # [cap + 1] int32: the destination rank of send row r
    slot_row: torch.Tensor      # [T, K] int32: the send row of top-k slot j (-1: masked, or an earlier slot's rank)
    vec: torch.Tensor           # [R + E] int64: rows per destination | tokens per expert (the exchanged vector)
    cap: int                    # the rows the plan can address: T * min(K, R)

    @property
    def send_counts(self) -> torch.Tensor:
        return self.vec[:self.start.numel()]

    @property
    def expert_counts(self) -> torch.Tensor:
        return self.vec[self.start.numel():]


@triton.jit
def _plan_scan_kernel(ids_ptr, row_pos_ptr, counts_ptr, ecount_ptr, T, R, NLOC, E,
                      K: tl.constexpr, BLOCK: tl.constexpr, EB: tl.constexpr):
    """Program d, one per destination rank: a sequential scan over the tokens. row_pos[t, d] = the token's position
    among the tokens with an expert on rank d (-1 for the others); counts[d] = their number. Program 0 also zeroes
    ecount[0:E] for the slot kernel's atomics."""
    d = tl.program_id(0)
    if d == 0:
        for e0 in range(0, E, EB):
            eo = e0 + tl.arange(0, EB)
            tl.store(ecount_ptr + eo, tl.zeros([EB], dtype=tl.int64), mask=eo < E)
    carry = d * 0
    for blk in range(0, T, BLOCK):
        offs = blk + tl.arange(0, BLOCK)
        tmask = offs < T
        member = offs < 0
        for k in tl.static_range(K):
            e = tl.load(ids_ptr + offs * K + k, mask=tmask, other=-1)
            member = member | ((e >= 0) & (e // NLOC == d))
        m32 = member.to(tl.int32)
        cm = tl.cumsum(m32, 0)
        tl.store(row_pos_ptr + offs * R + d, tl.where(member, carry + cm - 1, -1), mask=tmask)
        carry += tl.sum(m32, 0)
    tl.store(counts_ptr + d, carry.to(tl.int64))


@triton.jit
def _plan_rows_kernel(row_pos_ptr, counts_ptr, start_ptr, row_tok_ptr, row_dst_ptr, T, R,
                      BLOCK: tl.constexpr, RP: tl.constexpr):
    """Program d: start[d] = the rows bound for the ranks before d; then row_tok / row_dst of rank d's rows at
    start[d] + row_pos[t, d]."""
    d = tl.program_id(0)
    ro = tl.arange(0, RP)
    start = tl.sum(tl.load(counts_ptr + ro, mask=ro < d, other=0), 0)
    tl.store(start_ptr + d, start)
    for blk in range(0, T, BLOCK):
        offs = blk + tl.arange(0, BLOCK)
        tmask = offs < T
        p = tl.load(row_pos_ptr + offs * R + d, mask=tmask, other=-1)
        m = tmask & (p >= 0)
        tl.store(row_tok_ptr + start + p, offs.to(tl.int32), mask=m)
        tl.store(row_dst_ptr + start + p, tl.zeros([BLOCK], dtype=tl.int32) + d, mask=m)


@triton.jit
def _plan_slots_kernel(ids_ptr, row_pos_ptr, start_ptr, slot_row_ptr, ecount_ptr, T, R, NLOC, E,
                       K: tl.constexpr, KP: tl.constexpr, BLOCK: tl.constexpr, EP: tl.constexpr):
    """One program per BLOCK tokens: slot k's send row (-1 for a masked slot or a repeat of an earlier slot's rank)
    and the expert histogram of the block's valid ids added to ecount (int64 atomics)."""
    pid = tl.program_id(0)
    offs = pid * BLOCK + tl.arange(0, BLOCK)
    tmask = offs < T
    kk = tl.arange(0, KP)
    m2 = tmask[:, None] & (kk < K)[None, :]
    e = tl.load(ids_ptr + offs[:, None] * K + kk[None, :], mask=m2, other=-1)        # [BLOCK, KP]
    valid = e >= 0
    dst = tl.where(valid, e // NLOC, -1)
    # slot k (axis 1) repeats an earlier slot k' < k (axis 2) with the same rank
    eq = (dst[:, :, None] == dst[:, None, :]) & valid[:, :, None] & (kk[None, :, None] > kk[None, None, :])
    first = valid & (tl.sum(eq.to(tl.int32), 2) == 0)
    dsafe = tl.maximum(dst, 0)
    pos = tl.load(row_pos_ptr + offs[:, None] * R + dsafe, mask=first, other=-1)
    pos = pos + tl.load(start_ptr + dsafe, mask=first, other=0).to(tl.int32)
    tl.store(slot_row_ptr + offs[:, None] * K + kk[None, :], tl.where(first, pos, -1), mask=m2)
    hist = tl.histogram(tl.reshape(tl.where(valid, e, E), [BLOCK * KP]), EP)
    eo = tl.arange(0, EP)
    tl.atomic_add(ecount_ptr + eo, hist.to(tl.int64), mask=eo < E)


@triton.jit
def _pack_rows_kernel(x_ptr, xs_ptr, ids_ptr, w_ptr, row_tok_ptr, row_dst_ptr, o32_ptr, o64_ptr, of_ptr,
                      xs_stride_t, xs_stride_g,
                      X_WORDS: tl.constexpr, S_WORDS: tl.constexpr, S_OFF: tl.constexpr, SP: tl.constexpr,
                      I_OFF64: tl.constexpr, W_OFF32: tl.constexpr, ROW32: tl.constexpr, ROW64: tl.constexpr,
                      K: tl.constexpr, KP: tl.constexpr, NLOC: tl.constexpr, BLOCK: tl.constexpr):
    """Send row r <- token row_tok[r] for rank row_dst[r]. x: [T, X_WORDS] int32 words; xs: the scales as int32
    words with strides (t, g); ids / w: [T, K] int32 / fp32; the send buffer viewed as int32 (o32, ROW32 words per
    row), int64 (o64, ROW64) and fp32 (of, ROW32)."""
    r = tl.program_id(0).to(tl.int64)
    t32 = tl.load(row_tok_ptr + r)
    if t32 >= 0:
        t = t32.to(tl.int64)
        d = tl.load(row_dst_ptr + r).to(tl.int64)
        for c in tl.static_range(0, X_WORDS, BLOCK):
            offs = c + tl.arange(0, BLOCK)
            m = offs < X_WORDS
            xv = tl.load(x_ptr + t * X_WORDS + offs, mask=m, other=0)
            tl.store(o32_ptr + r * ROW32 + offs, xv, mask=m)
        if S_WORDS > 0:                                      # strided source: the column-major UE8M0 layout
            so = tl.arange(0, SP)
            sm = so < S_WORDS
            sv = tl.load(xs_ptr + t * xs_stride_t + so * xs_stride_g, mask=sm, other=0)
            tl.store(o32_ptr + r * ROW32 + S_OFF + so, sv, mask=sm)
        ks = tl.arange(0, KP)
        km = ks < K
        ids = tl.load(ids_ptr + t * K + ks, mask=km, other=-1).to(tl.int64)
        w = tl.load(w_ptr + t * K + ks, mask=km, other=0.0)
        local = (ids >= 0) & (ids // NLOC == d)
        tl.store(o64_ptr + r * ROW64 + I_OFF64 + ks, tl.where(local, ids - d * NLOC, -1), mask=km)
        tl.store(of_ptr + r * ROW32 + W_OFF32 + ks, tl.where(local, w, 0.0), mask=km)


@triton.jit
def _combine_kernel(recv_ptr, slot_ptr, out_ptr, H: tl.constexpr, K: tl.constexpr, BLOCK: tl.constexpr):
    """out[t] = the fp32 sum over the token's rows slot_row[t, j] >= 0 of recv[row]."""
    t = tl.program_id(0).to(tl.int64)
    slots = slot_ptr + t * K
    for c in tl.static_range(0, H, BLOCK):
        offs = c + tl.arange(0, BLOCK)
        m = offs < H
        acc = tl.zeros([BLOCK], dtype=tl.float32)
        for j in tl.static_range(K):
            # the row per lane: Triton 3.9's interpreter refuses a mask from a scalar comparison (3.7 took it)
            rv = tl.zeros([BLOCK], dtype=tl.int64) + tl.load(slots + j).to(tl.int64)
            v = tl.load(recv_ptr + rv * H + offs, mask=m & (rv >= 0), other=0.0)
            acc += v.to(tl.float32)
        tl.store(out_ptr + t * H + offs, acc.to(out_ptr.dtype.element_ty), mask=m)


def scale_words(x_s: Optional[torch.Tensor], fallback: torch.Tensor):
    """The scales as int32 words and their (token, group) strides; the hidden words stand in without scales."""
    if x_s is None:
        return fallback, 0, 0
    xs32 = x_s if x_s.dtype == torch.int32 else x_s.view(torch.int32)
    return xs32, xs32.stride(0), xs32.stride(1)


class FusedCore(RowLayout):
    """Device plan, count vector, pack, receive and combine of the fused path."""

    BLOCK_X = 2048          # int32 words per chunk of the hidden row (a 7168-byte FP8 row is one chunk)
    BLOCK_H = 1024          # elements per chunk of the combine reduction
    PLAN_BLOCK_T = 1024     # tokens per scan step (the scan and row-map kernels)
    PLAN_BLOCK_S = 128      # tokens per program of the slot kernel

    def plan(self, topk_ids: torch.Tensor) -> FusedPlan:
        """Three launches, no host wait; the count vector is written in place."""
        T, K = topk_ids.shape
        R, E, nloc = self.world, self.num_experts, self.num_local_experts
        dev = topk_ids.device
        ids = topk_ids if topk_ids.dtype == torch.int32 and topk_ids.is_contiguous() else \
            topk_ids.to(torch.int32).contiguous()
        cap = T * min(K, R)
        vec = torch.empty(R + E, dtype=torch.int64, device=dev)
        row_pos = torch.empty(T, R, dtype=torch.int32, device=dev)
        start = torch.empty(R, dtype=torch.int64, device=dev)
        row_tok = torch.empty(cap + 1, dtype=torch.int32, device=dev)
        row_dst = torch.empty(cap + 1, dtype=torch.int32, device=dev)
        slot_row = torch.empty(T, K, dtype=torch.int32, device=dev)
        ep = max(2, triton.next_power_of_2(E + 1))
        _plan_scan_kernel[(R,)](ids, row_pos, vec, vec[R:], T, R, nloc, E,
                                K=K, BLOCK=self.PLAN_BLOCK_T, EB=min(ep, 1024), num_warps=4)
        _plan_rows_kernel[(R,)](row_pos, vec, start, row_tok, row_dst, T, R,
                                BLOCK=self.PLAN_BLOCK_T, RP=max(2, triton.next_power_of_2(R)), num_warps=4)
        if T:
            _plan_slots_kernel[(triton.cdiv(T, self.PLAN_BLOCK_S),)](
                ids, row_pos, start, slot_row, vec[R:], T, R, nloc, E,
                K=K, KP=self.kp, BLOCK=self.PLAN_BLOCK_S, EP=ep, num_warps=4)
        return FusedPlan(row_pos, start, row_tok, row_dst, slot_row, vec, cap)

    def check_table(self, table: np.ndarray, T: int) -> None:
        """The gathered [R, R + E] table, before any buffer is sized from it: nothing negative, every source's rows
        between its slots / k and its slots, this rank's rows at most its plan's capacity."""
        R, K = self.world, self.topk
        rows = table[:, :R].sum(1)
        slots = table[:, R:].sum(1)
        if (table < 0).any() or (rows > slots).any() or (rows * K < slots).any() or rows[self.rank] > T * min(K, R):
            raise RuntimeError(f"inconsistent count table on rank {self.rank} (T={T}): rows per source "
                               f"{rows.tolist()}, top-k slots per source {slots.tolist()}")

    def pack(self, x_q: torch.Tensor, x_s: Optional[torch.Tensor], topk_ids: torch.Tensor,
             topk_weights: torch.Tensor, plan: FusedPlan, rows: int) -> torch.Tensor:
        """The send buffer of exactly `rows` rows (this rank's row of the gathered table), one launch."""
        T = topk_ids.shape[0]
        if not 0 <= rows <= plan.cap:
            raise ValueError(f"{rows} send rows outside [0, {plan.cap}]")
        send = torch.empty(rows, self.row_bytes, dtype=torch.uint8, device=topk_ids.device)
        if T == 0 or rows == 0:
            return send
        x32 = x_q.contiguous().view(torch.uint8).view(T, -1).view(torch.int32)
        xs32, st, sg = scale_words(x_s if self.s_words else None, x32)
        _pack_rows_kernel[(rows,)](x32, xs32, topk_ids.to(torch.int32).contiguous(),
                                   topk_weights.to(torch.float32).contiguous(), plan.row_tok, plan.row_dst,
                                   send.view(torch.int32), send.view(torch.int64), send.view(torch.float32), st, sg,
                                   X_WORDS=self.x_words, S_WORDS=self.s_words, S_OFF=self.off_s // 4, SP=self.sp,
                                   I_OFF64=self.off_i // 8, W_OFF32=self.off_w // 4, ROW32=self.row_bytes // 4,
                                   ROW64=self.row_bytes // 8, K=self.topk, KP=self.kp,
                                   NLOC=self.num_local_experts, BLOCK=self.BLOCK_X, num_warps=4)
        return send

    def unpack(self, recv: torch.Tensor, x_dtype: torch.dtype, s_dtype: Optional[torch.dtype]):
        """Strided views of the received hidden rows and scales (DeepGEMM's pre-permute reads them by stride) and
        contiguous ids and weights."""
        hidden = recv[:, self.off_x:self.off_x + self.x_bytes].view(x_dtype)
        scales = recv[:, self.off_s:self.off_s + self.s_bytes].view(s_dtype) if self.s_bytes else None
        ids = recv[:, self.off_i:self.off_i + self.i_bytes].view(torch.int64).contiguous()
        weights = recv[:, self.off_w:self.off_w + self.w_bytes].view(torch.float32).contiguous()
        return hidden, scales, ids, weights

    def local_counts(self, table: np.ndarray) -> list[int]:
        """Rows per local expert, aligned, from the gathered [R, R + E] table."""
        lo = self.world + self.rank * self.num_local_experts
        return self.aligned(table[:, lo:lo + self.num_local_experts].sum(0))

    def combine(self, recv_rows: torch.Tensor, slot_row: torch.Tensor, num_tokens: int,
                out_dtype: torch.dtype) -> torch.Tensor:
        """The per-token sum of the returned rows, one launch."""
        H = recv_rows.shape[1]
        out = torch.empty(num_tokens, H, dtype=out_dtype, device=recv_rows.device)
        if num_tokens == 0:
            return out
        if recv_rows.shape[0] == 0:
            return out.zero_()
        _combine_kernel[(num_tokens,)](recv_rows.contiguous(), slot_row, out, H=H, K=self.topk,
                                       BLOCK=self.BLOCK_H, num_warps=4)
        return out
