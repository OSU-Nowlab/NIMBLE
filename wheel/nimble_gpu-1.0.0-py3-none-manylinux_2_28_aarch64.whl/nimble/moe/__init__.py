"""Expert-parallel MoE dispatch and combine over NIMBLE's AllToAllV (needs torch 2.13 and Triton).

    Dispatcher   DeepEP-normal dispatch and combine for one expert-parallel group (dispatcher.py)
    FusedCore    the fused path: one AllToAllV per direction, NIMBLE or torch.distributed (fused.py)
    DedupCore    the dedup path: one NIMBLE dedup collective per direction (dedup.py)
    RowLayout    the wire row both paths share (core.py)

nimble.integrations.sglang and nimble.integrations.vllm build their frameworks' dispatchers on Dispatcher.
"""
from .core import RowLayout
from .dedup import DedupCore, DedupPlan
from .dispatcher import Dispatched, Dispatcher
from .fused import FusedCore, FusedPlan

__all__ = ["Dispatcher", "Dispatched", "FusedCore", "FusedPlan", "DedupCore", "DedupPlan", "RowLayout"]
