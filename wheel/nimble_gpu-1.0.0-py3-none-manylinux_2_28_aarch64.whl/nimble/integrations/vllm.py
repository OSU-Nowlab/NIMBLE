# SPDX-License-Identifier: Apache-2.0
"""NIMBLE's MoE backend for vLLM.

vLLM's patch series (tools/vllm_ep/setup/vllm, vLLM 0.30.0) registers two all-to-all backends:

    --all2all-backend nimble     NIMBLE's AllToAllV (nimble.moe.Dispatcher, transport "nimble")
    --all2all-backend nccl_a2a   the same dispatcher over torch.distributed.all_to_all_single on the expert-parallel
                                 group, i.e. NCCL: the baseline that differs from nimble only in the transport

Its CUDA communicator builds NimbleAll2AllManager for them, and its prepare / finalize factory calls
NimblePrepareAndFinalize.make. The contract is vLLM's Standard activation format, as for its DeepEP high-throughput
backend: prepare quantizes as that backend does (block-128 FP8 with FP32 scales for block-quantized layers, BF16
otherwise), dispatches DeepEP-normal rows and hands the experts contiguous copies of the received rows with their
top-k ids in vLLM's global expert space (an expert on another rank -> one outside this rank, which vLLM's expert map
drops); finalize applies the experts' weight-and-reduce, combines and writes the layer's output.

VLLM_NIMBLE_DISPATCHER selects the nimble backend's mode: fused (the default; one AllToAllV per direction) or dedup
(the MoE two-hop inside one NIMBLE call per direction; needs two or more nodes and NIMBLE_DEDUP=1 in every rank's
environment). The dispatch reads its count table on the host, so the patch turns CUDA graphs off for both backends,
and vLLM's micro-batching is refused (one communicator, one stream). NIMBLE's executor waits without a time limit
unless NIMBLE_ENGINE_WAIT_BUDGET_MS says otherwise: vLLM's first forward compiles and tunes the experts on the ranks
that received tokens while the others already wait in the combine, minutes apart; a peer that dies still ends the
call. The modules import vLLM: import them inside it only.
"""
from __future__ import annotations

import os
import time

import torch

import vllm.model_executor.layers.fused_moe.modular_kernel as mk
from vllm.config import get_current_vllm_config_or_none
from vllm.distributed.device_communicators.base_device_communicator import All2AllManagerBase
from vllm.logger import init_logger
from vllm.model_executor.layers.fused_moe.config import FusedMoEQuantConfig
from vllm.model_executor.layers.fused_moe.topk_weight_and_reduce import (TopKWeightAndReduceContiguous,
                                                                         TopKWeightAndReduceDelegate)
from vllm.model_executor.layers.fused_moe.utils import moe_kernel_quantize_input
from vllm.platforms import current_platform

import nimble
from nimble.moe import Dispatcher

# under vLLM's logger hierarchy ("vllm.*"): vLLM attaches its handler there only
logger = init_logger(f"vllm.{__name__}")

BLOCK_SHAPE = [128, 128]


class NimbleAll2AllManager(All2AllManagerBase):
    """The expert-parallel group's NIMBLE side: its device group (the count exchange and the nccl_a2a transport) and,
    for --all2all-backend nimble, one NIMBLE communicator over the group (created on its CPU group the first time a
    layer asks; every layer's dispatcher shares it)."""

    def __init__(self, cpu_group, tcp_store_group=None):
        vllm_config = get_current_vllm_config_or_none()
        if vllm_config is not None and getattr(vllm_config.parallel_config, "use_ubatching", False):
            raise NotImplementedError("--all2all-backend nimble / nccl_a2a runs one dispatch and combine at a time on "
                                      "one stream: vLLM's micro-batching (--enable-dbo) is not supported")
        super().__init__(cpu_group, tcp_store_group)
        self.backend = vllm_config.parallel_config.all2all_backend if vllm_config is not None else "nimble"
        self.device_group = None
        self.comm = None

    def get_handle(self, kwargs):
        if self.device_group is None:          # the EP group is complete once its layers ask
            from vllm.distributed.parallel_state import get_ep_group
            self.device_group = get_ep_group().device_group
        if self.backend == "nimble" and self.comm is None:
            os.environ.setdefault("NIMBLE_ENGINE_WAIT_BUDGET_MS", "0")
            start = time.time()
            self.comm = nimble.init(group=self.cpu_group, device=torch.cuda.current_device(), set_default=False)
            logger.info("NIMBLE communicator %s ready in %.1f s (%s)", self.comm, time.time() - start,
                        nimble.version_string())
        return self

    def destroy(self):
        if self.comm is not None:
            self.comm.destroy()
            self.comm = None


class NimblePrepareAndFinalize(mk.FusedMoEPrepareAndFinalizeModular):
    """Prepare / finalize over nimble.moe.Dispatcher in vLLM's Standard format (see the module docstring)."""

    @classmethod
    def make(cls, moe, quant_config: FusedMoEQuantConfig | None, all2all_manager) -> "NimblePrepareAndFinalize":
        """vLLM's factory entry (all2all_utils.maybe_make_prepare_finalize): one per MoE layer."""
        manager = all2all_manager.get_handle({})
        if quant_config is not None and quant_config.quant_dtype is not None:
            if quant_config.quant_dtype != current_platform.fp8_dtype() or \
                    list(quant_config.block_shape or []) != BLOCK_SHAPE:
                raise NotImplementedError(f"--all2all-backend {manager.backend} dispatches block-128 FP8 or BF16; the "
                                          f"layer quantizes to {quant_config.quant_dtype} with block shape "
                                          f"{quant_config.block_shape}")
            x_dtype, scale_dtype, scale_cols = current_platform.fp8_dtype(), torch.float32, moe.hidden_dim // 128
        else:
            x_dtype, scale_dtype, scale_cols = torch.bfloat16, None, 0
        mode = os.environ.get("VLLM_NIMBLE_DISPATCHER", "fused") if manager.backend == "nimble" else "fused"
        if mode not in ("fused", "dedup"):
            raise ValueError(f"VLLM_NIMBLE_DISPATCHER={mode!r}: fused or dedup")
        if mode == "dedup" and os.environ.get("NIMBLE_DEDUP") != "1":
            raise RuntimeError("VLLM_NIMBLE_DISPATCHER=dedup needs NIMBLE_DEDUP=1 in every rank's environment")
        dispatcher = Dispatcher(manager.device_group, num_experts=moe.num_experts, hidden_size=moe.hidden_dim,
                                topk=moe.experts_per_token, x_dtype=x_dtype, scale_dtype=scale_dtype,
                                scale_cols=scale_cols, mode=mode,
                                transport="nimble" if manager.backend == "nimble" else "torch", comm=manager.comm,
                                max_tokens=moe.max_num_tokens)
        logger.info_once("--all2all-backend %s: mode %s, %s rows of %d B, EP %d", manager.backend, mode, x_dtype,
                         dispatcher.core.row_bytes, all2all_manager.world_size)
        return cls(dispatcher, all2all_manager.world_size, all2all_manager.rank * moe.num_local_experts,
                   moe.max_num_tokens)

    def __init__(self, dispatcher: Dispatcher, num_dispatchers: int, rank_expert_offset: int, max_tokens: int):
        super().__init__()
        self.dispatcher = dispatcher
        self.num_dispatchers_ = int(num_dispatchers)
        self.rank_expert_offset = int(rank_expert_offset)
        self.max_tokens = int(max_tokens)
        self._pending = None            # (handle, tokens, received rows) of the dispatch until its finalize
        self._tuner = None              # FlashInfer's autotuner while the experts are tuned in lockstep

    def post_init_setup(self, fused_experts: mk.FusedMoEExperts):
        """vLLM's start-up warm-up autotunes FlashInfer's TRT-LLM experts with every rank in one group, each tactic's
        timing all-reduced, so every rank must profile the same shapes in the same order; the rows a rank receives
        differ by rank. While FlashInfer tunes, the hand-off is padded to the most rows a rank can receive (rows past
        the received ones name an expert outside the rank: computed by no one)."""
        try:
            from vllm.model_executor.layers.fused_moe.experts.trtllm_fp8_moe import TrtLlmFp8ExpertsModular
            if isinstance(fused_experts, TrtLlmFp8ExpertsModular):
                from flashinfer.autotuner import AutoTuner
                self._tuner = AutoTuner.get()
        except ImportError:
            self._tuner = None

    @property
    def activation_format(self) -> mk.FusedMoEActivationFormat:
        return mk.FusedMoEActivationFormat.Standard

    def topk_indices_dtype(self) -> torch.dtype | None:
        return torch.int64

    def max_num_tokens_per_rank(self) -> int | None:
        return None

    def num_dispatchers(self) -> int:
        return self.num_dispatchers_

    def output_is_reduced(self) -> bool:
        return True

    def supports_async(self) -> bool:
        return False

    def prepare(self, a1: torch.Tensor, topk_weights: torch.Tensor, topk_ids: torch.Tensor, num_experts: int,
                expert_map: torch.Tensor | None, apply_router_weight_on_input: bool,
                quant_config: FusedMoEQuantConfig, defer_input_quant: bool = False) -> mk.PrepareResultType:
        if apply_router_weight_on_input:
            raise NotImplementedError("--all2all-backend nimble / nccl_a2a: apply_router_weight_on_input is not "
                                      "supported (vLLM's experts apply the weights)")
        if defer_input_quant and self.dispatcher.x_dtype != torch.bfloat16:
            raise NotImplementedError("--all2all-backend nimble / nccl_a2a dispatches the layer's FP8; experts that "
                                      "take unquantized inputs (defer_input_quant) are not supported")
        if self._pending is not None:
            raise RuntimeError("--all2all-backend nimble / nccl_a2a: a dispatch while the previous one has no finalize")
        T = a1.size(0)
        d = self.dispatcher
        if d.scale_dtype is None:
            x, x_scales = a1, None
        elif T:
            x, x_scales = moe_kernel_quantize_input(a1, quant_config.a1_scale, quant_dtype=quant_config.quant_dtype,
                                                    per_act_token_quant=False, block_shape=BLOCK_SHAPE)
        else:                           # an idle rank still joins the collectives; no quantizer on no rows
            x = torch.empty(0, d.hidden_size, dtype=d.x_dtype, device=a1.device)
            x_scales = torch.empty(0, d.scale_cols, dtype=d.scale_dtype, device=a1.device)
        out = d.dispatch(x, x_scales, topk_ids, topk_weights)
        n = out.hidden.shape[0]
        self._pending = (out.handle, T, n)
        m = self.dispatcher.world * self.max_tokens if self._tuner is not None and self._tuner.is_tuning_mode else n
        outside = num_experts - 1 if self.rank_expert_offset == 0 else 0
        expert_x = (torch.empty if m == n else torch.zeros)(m, d.hidden_size, dtype=d.x_dtype, device=a1.device)
        expert_x[:n] = out.hidden
        expert_scales = None
        if out.scales is not None:
            expert_scales = torch.ones(m, d.scale_cols, dtype=d.scale_dtype, device=a1.device)
            expert_scales[:n] = out.scales
        expert_ids = torch.full((m, d.topk), outside, dtype=torch.int64, device=a1.device)
        expert_ids[:n] = torch.where(out.topk_ids < 0, outside, out.topk_ids + self.rank_expert_offset)
        expert_weights = torch.zeros(m, d.topk, dtype=torch.float32, device=a1.device)
        expert_weights[:n] = out.topk_weights
        counts = mk.ExpertTokensMetadata.make_from_list(out.expert_counts, device=a1.device)
        return expert_x, expert_scales, counts, expert_ids, expert_weights

    def finalize(self, output: torch.Tensor, fused_expert_output: torch.Tensor, topk_weights: torch.Tensor,
                 topk_ids: torch.Tensor, apply_router_weight_on_input: bool,
                 weight_and_reduce_impl: mk.TopKWeightAndReduce) -> None:
        if self._pending is None:
            raise RuntimeError("--all2all-backend nimble / nccl_a2a: a finalize without a pending dispatch")
        (handle, T, n), self._pending = self._pending, None
        if output.size(0) != T:
            raise RuntimeError(f"--all2all-backend nimble / nccl_a2a: the output holds {output.size(0)} tokens, the "
                               f"dispatch sent {T}")
        y = fused_expert_output
        if y.numel():                   # as vLLM's DeepEP high-throughput finalize
            if isinstance(weight_and_reduce_impl, TopKWeightAndReduceDelegate):
                weight_and_reduce_impl = TopKWeightAndReduceContiguous()
            y = weight_and_reduce_impl.apply(output=None, fused_expert_output=y, topk_weights=topk_weights,
                                             topk_ids=topk_ids, apply_router_weight_on_input=False)
        else:                           # no rows here: the experts' (0, top-k, hidden) output, still a combine
            y = y.new_empty(0, self.dispatcher.hidden_size)
        output.copy_(self.dispatcher.combine(y[:n], handle), non_blocking=True)    # the padded rows stay here
