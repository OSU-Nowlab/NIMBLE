"""NIMBLE's MoE dispatcher for SGLang.

SGLang's serving series (tools/sglang_ep/setup/sglang, at SGLang fbf8f1d) registers two MoE all-to-all backends
that build NimbleEPDispatcher:

    --moe-a2a-backend nimble     NIMBLE's AllToAllV (nimble.moe.Dispatcher, transport "nimble")
    --moe-a2a-backend nccl_a2a   the same dispatcher over torch.distributed.all_to_all_single on the expert-parallel
                                 group, i.e. NCCL: the baseline that differs from nimble only in the transport

SGLANG_NIMBLE_DISPATCHER selects the nimble backend's mode: fused (the default; one AllToAllV per direction) or
dedup (the MoE two-hop inside one NIMBLE call per direction; needs two or more nodes and NIMBLE_DEDUP=1 in every
rank's environment, and SGLANG_NIMBLE_MAX_TOKENS, default 16384, bounds the tokens per rank and call). The output is
SGLang's DeepEPNormalDispatchOutput, so DeepEPMoE's expert path runs unchanged; the activations are quantized here as
SGLang's DeepEP backend quantizes them (FP8 in 128-element groups when DeepGEMM is on, UE8M0 scales when DeepGEMM
asks).

One NIMBLE communicator per process serves every layer's dispatcher: nimble.init over the expert-parallel group at
the first nimble dispatcher. Its executor waits without a time limit unless NIMBLE_ENGINE_WAIT_BUDGET_MS says
otherwise: a server's first forward compiles kernels on the ranks that received tokens while the others already wait
in the combine, minutes apart, and a peer that dies still ends the call (its connection closes).
"""
from __future__ import annotations

import logging
import os
import time

import torch
from sglang.srt.layers.moe.token_dispatcher.base import BaseDispatcher

import nimble
from nimble.moe import Dispatcher

logger = logging.getLogger(__name__)

_communicator = None     # the process's NIMBLE communicator, shared by every layer's dispatcher


def _process_communicator(group) -> nimble.Communicator:
    global _communicator
    if _communicator is None:
        os.environ.setdefault("NIMBLE_ENGINE_WAIT_BUDGET_MS", "0")
        start = time.time()
        _communicator = nimble.init(group=group, device=torch.cuda.current_device(), set_default=False)
        logger.info("NIMBLE communicator %s ready in %.1f s (%s)", _communicator, time.time() - start,
                    nimble.version_string())
    return _communicator


class NimbleEPDispatcher(BaseDispatcher):
    """DeepEP-normal dispatch and combine over nimble.moe.Dispatcher, constructed by SGLang's
    MaybeTboDeepEPDispatcher with DeepEPDispatcher's keyword arguments (see the module docstring)."""

    def __init__(self, group, router_topk: int, permute_fusion: bool = False, num_experts: int = None,
                 num_local_experts: int = None, hidden_size: int = None, params_dtype=None, deepep_mode=None,
                 async_finish: bool = False, return_recv_hook: bool = False):
        super().__init__()
        from sglang.srt.environ import envs
        from sglang.srt.layers import deep_gemm_wrapper
        from sglang.srt.layers.moe.utils import get_moe_a2a_backend

        over_nimble = get_moe_a2a_backend().is_nimble()
        mode = os.environ.get("SGLANG_NIMBLE_DISPATCHER", "fused") if over_nimble else "fused"
        if mode not in ("fused", "dedup"):
            raise ValueError(f"SGLANG_NIMBLE_DISPATCHER={mode!r}: fused or dedup")
        if mode == "dedup" and os.environ.get("NIMBLE_DEDUP") != "1":
            raise RuntimeError("SGLANG_NIMBLE_DISPATCHER=dedup needs NIMBLE_DEDUP=1 in every rank's environment")
        self.use_fp8 = bool(deep_gemm_wrapper.ENABLE_JIT_DEEPGEMM) and not envs.SGLANG_DEEPEP_BF16_DISPATCH.get()
        self.scale_ue8m0 = bool(deep_gemm_wrapper.DEEPGEMM_SCALE_UE8M0)
        groups = hidden_size // 128
        if self.use_fp8:
            x_dtype = torch.float8_e4m3fn
            scale_dtype, scale_cols = (torch.int32, (groups + 3) // 4) if self.scale_ue8m0 else (torch.float32, groups)
        else:
            x_dtype, scale_dtype, scale_cols = torch.bfloat16, None, 0
        self.dispatcher = Dispatcher(
            group, num_experts=num_experts, hidden_size=hidden_size, topk=router_topk, x_dtype=x_dtype,
            scale_dtype=scale_dtype, scale_cols=scale_cols,
            expert_alignment=128 if deep_gemm_wrapper.ENABLE_JIT_DEEPGEMM else 1, mode=mode,
            transport="nimble" if over_nimble else "torch",
            comm=_process_communicator(group) if over_nimble else None,
            max_tokens=int(os.environ.get("SGLANG_NIMBLE_MAX_TOKENS", "16384")))
        self.expert_mask_gpu = None
        self._handle = None
        self._dispatch_output = None
        self._combine_output = None
        if self.dispatcher.rank == 0:
            logger.info("NimbleEPDispatcher transport=%s mode=%s fp8=%s ue8m0=%s row=%d B experts=%d topk=%d",
                        self.dispatcher.transport, mode, self.use_fp8, self.scale_ue8m0,
                        self.dispatcher.core.row_bytes, num_experts, router_topk)

    def dispatch(self, hidden_states: torch.Tensor, topk_output):
        from sglang.srt.layers.moe.token_dispatcher.deepep import DeepEPNormalDispatchOutput

        if self.use_fp8:
            from sglang.kernels.ops.quantization.fp8_kernel import sglang_per_token_group_quant_fp8
            x, x_scales = sglang_per_token_group_quant_fp8(
                hidden_states, 128, column_major_scales=self.scale_ue8m0, scale_tma_aligned=self.scale_ue8m0,
                scale_ue8m0=self.scale_ue8m0)
        else:
            x, x_scales = hidden_states, None
        out = self.dispatcher.dispatch(x, x_scales, topk_output.topk_ids, topk_output.topk_weights)
        self._handle = out.handle
        return DeepEPNormalDispatchOutput(out.hidden, out.scales, out.topk_ids, out.topk_weights, out.expert_counts)

    def combine(self, combine_input) -> torch.Tensor:
        hidden_states = combine_input[0]           # DeepEPNormalCombineInput(hidden_states, topk_ids, topk_weights)
        handle, self._handle = self._handle, None
        return self.dispatcher.combine(hidden_states, handle)

    def dispatch_a(self, hidden_states: torch.Tensor, topk_output):
        self._dispatch_output = self.dispatch(hidden_states, topk_output)

    def dispatch_b(self):
        out, self._dispatch_output = self._dispatch_output, None
        return out

    def combine_a(self, combine_input):
        self._combine_output = self.combine(combine_input)

    def combine_b(self):
        out, self._combine_output = self._combine_output, None
        return out
